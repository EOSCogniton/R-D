/*
 * vehicle_logic.c
 *
 * Created: 02/06/2026 16:52:56
 *  Author: maxbo
 */ 

#include <atmel_start.h>

void vehicle_logic_init(void){
	
}

void vehicle_logic_safety_check(void){
	
}