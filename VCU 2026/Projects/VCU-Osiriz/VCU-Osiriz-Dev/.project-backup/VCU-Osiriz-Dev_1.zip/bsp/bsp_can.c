/*
 * bsp_can.c
 * Created: 02/06/2026
 * Author: maxbo
 */ 

#include <atmel_start.h> 
#include <stdio.h>
#include "bsp_can.h"   


static struct can_message received_msg;
static uint8_t rx_data[8];


void bsp_can_init(void) {
    can_async_enable(&CAN_0);
       
    // Liaison de la structure de r�ception (RX) � son buffer physique
    received_msg.data = rx_data;
}


void bsp_can_read(void) {
    if (can_async_read(&CAN_0, &received_msg) == ERR_NONE) {
        
        // On a re�u un message ! On affiche ses infos dans PuTTY
        printf("[CAN RX] Message recu ! ID: 0x%03X | DLC: %d | Data: ",
               received_msg.id, received_msg.len);
        
        for (uint8_t i = 0; i < received_msg.len; i++) {
            printf("%02X ", rx_data[i]);
        }
        printf("\r\n");
        
        // Exemple d'action selon l'ID
        if (received_msg.id == 0x500) {
            printf("-> Ordre specifique recu sur l'ID 0x500 !\r\n");
        }
    }
}

void bsp_can_send(uint32_t id, uint8_t data){
	
}


void bsp_disable_inverter(void){
	
}

void bsp_enable_inverter(void){
	
}
