/*
 * bsp_can.c
 * Created: 02/06/2026
 * Author: maxbo
 */ 

#include <atmel_start.h> 
#include <stdio.h>
#include "bsp_can.h" 
#include "bsp_analog.h"  


static struct can_message received_msg;
static uint8_t rx_data[8];


void bsp_can_init(void) {
    can_async_enable(&CAN_0);
       
    // Liaison de la structure de r�ception (RX) � son buffer physique
    received_msg.data = rx_data;
}


void bsp_can_read(void) {
    if (can_async_read(&CAN_0, &received_msg) == ERR_NONE) {
        
        printf("[CAN RX] Message recu ! ID: 0x%03X | DLC: %d | Data: ",
               received_msg.id, received_msg.len);
        
        for (uint8_t i = 0; i < received_msg.len; i++) {
            printf("%02X ", rx_data[i]);
        }
        printf("\r\n");
        
        if (received_msg.id == 0x500) {
            printf("-> Message can de tests R2D re�u !\r\n");
			uint8_t flags = rx_data[0];
			
			ts_active      = (flags & (1 << 0)) != 0; // Vrai si le bit 0 est � 1
			bsp_brake_pressed = (flags & (1 << 1)) != 0; // Vrai si le bit 1 est � 1
			bsp_start_button   = (flags & (1 << 2)) != 0; // Vrai si le bit 2 est � 1
        }
    }
}

void bsp_can_send(uint32_t id, uint8_t *data, uint8_t length) {
	struct can_message tx_msg;
	tx_msg.id   = id;
	tx_msg.type = CAN_TYPE_DATA;
	tx_msg.data = data;
	tx_msg.len  = length;
	can_async_write(&CAN_0, &tx_msg);
}


void bsp_disable_inverter(void){
	
}

void bsp_enable_inverter(void){
	
}
