#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		
		bool inputstate = false;
		
		inputstate = gpio_get_pin_level(DigitalInputTest);
		if(inputstate == true){
			printf("true\n\r");	
		}else{
			printf("false\n\r");
		}
		
	}
}
