#include <atmel_start.h>
#include <stdio.h>

struct can_message my_tx_msg;
uint8_t tx_data[4] = {0xAA, 0xBB, 0xCC, 0x00}; 

void can_system_init(void){
	can_async_enable(&CAN_0);
	my_tx_msg.id   = 0x123;       // ID du message (11 bits)
	my_tx_msg.type = CAN_TYPE_DATA;
	my_tx_msg.len  = 4;           // On envoie 4 octets
	my_tx_msg.data = tx_data;     // Pointeur vers notre tableau de donn�es
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	can_system_init();
	gpio_set_pin_level(GPIO(GPIO_PORTA, 23), false); // Mode normal (pas de standby)

	
	bool inputValue = false;

	/* Replace with your application code */
	while (1) {
		
		inputValue = gpio_get_pin_level(DigitalInputTest);
		if(inputValue == true){
			printf("True\n\r");
			
		}else{
			printf("False\n\r");
		}
		gpio_set_pin_level(DigitalOutputTest, inputValue);
		
		// Faire �voluer le dernier octet pour voir le message changer
		tx_data[3]++;

		// Envoi du message via l'API Atmel START
		// Arguments : (&instance, num�ro_de_boite_mail_tx, &structure_du_message)
		/*int32_t status = can_async_write(&CAN_0, &my_tx_msg);
		

		if (status == ERR_NONE) {
			printf("[CAN] Message envoy� avec succ�s ! Donn�e variable : 0x%02X\r\n", tx_data[3]);
			} else {
			printf("[CAN] Erreur d'envoi (%ld). Pas de ACK ?\r\n", status);
		}*/

		// Attendre 1 seconde avant le prochain envoi
		delay_ms(1000);
		
	}
}
