#include <atmel_start.h>
#include <stdio.h>

struct can_message my_tx_msg;
uint8_t tx_data[4] = {0xAA, 0xBB, 0xCC, 0x00}; 
	
struct can_message my_rx_msg;
uint8_t rx_data[8];

void can_system_init(void){
	can_async_enable(&CAN_0);
	my_tx_msg.id   = 0x123;       // ID du message (11 bits)
	my_tx_msg.type = CAN_TYPE_DATA;
	my_tx_msg.len  = 4;           // On envoie 4 octets
	my_tx_msg.data = tx_data;     // Pointeur vers notre tableau de donn�es
	
	my_rx_msg.data = rx_data;
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	can_system_init();
	gpio_set_pin_level(GPIO(GPIO_PORTA, 23), false); // Mode normal (pas de standby)

	
	bool inputValue = false;

	/* Replace with your application code */
	while (1) {
		
		inputValue = gpio_get_pin_level(DigitalInputTest);
		if(inputValue == true){
			printf("True\n\r");
			
		}else{
			printf("False\n\r");
		}
		gpio_set_pin_level(DigitalOutputTest, inputValue);
		
		if (can_async_read(&CAN_0, &my_rx_msg) == ERR_NONE) {
			
			// On a re�u un message ! On affiche ses infos dans PuTTY
			printf("[CAN RX] Message re�u ! ID: 0x%03X | DLC: %d | Data: ",
			my_rx_msg.id, my_rx_msg.len);
			
			for (uint8_t i = 0; i < my_rx_msg.len; i++) {
				printf("%02X ", rx_data[i]);
			}
			printf("\r\n");
			
			// Exemple d'action : si on re�oit l'ID 0x500, on fait quelque chose
			if (my_rx_msg.id == 0x500) {
				printf("-> Ordre sp�cifique re�u sur l'ID 0x500 !\r\n");
			}
		}

		delay_ms(1000);
		
	}
}
