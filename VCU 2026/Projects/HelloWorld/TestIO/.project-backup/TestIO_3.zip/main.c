#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	bool inputValue = false;

	/* Replace with your application code */
	while (1) {
		inputValue = gpio_get_pin_level(DigitalInputTest);
		if(inputValue == true){
			printf("True\n\r");
			
		}else{
			printf("False\n\r");
		}
		gpio_set_pin_level(DigitalOutputTest, inputValue);
		
	}
}
